from langdetect import detect
from indic_transliteration import sanscript
from indic_transliteration.sanscript import transliterate

def detect_language(text):
    return detect(text)

def transliterate(text, src_lang, target_script):
    return transliterate(text, sanscript.ITRANS, sanscript.DEVANAGARI)