# Folk Lore Hub

Streamlit-based app to collect Indian folk stories in multiple languages.

## Features
- Text & speech story submission
- Works offline with sync
- Auto language detection & transliteration

## Install
pip install -r requirements.txt
streamlit run app/main.py