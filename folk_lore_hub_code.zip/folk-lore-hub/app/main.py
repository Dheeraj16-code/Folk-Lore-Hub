import streamlit as st
from utils.translator import detect_language, transliterate
from utils.storage import save_story

st.title("🌟 Folk Lore Hub")
st.subheader("Preserve your region's stories")

story = st.text_area("Enter your story or proverb")
language = st.selectbox("Language", ["Hindi", "Telugu", "Tamil", "Kannada", "Odia", "Punjabi"])

if st.button("Submit"):
    lang_code = detect_language(story)
    story_dev = transliterate(story, lang_code, "Devanagari")
    save_story(story, lang_code)
    st.success("🚀 Submitted successfully!")