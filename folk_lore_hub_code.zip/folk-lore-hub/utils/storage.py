import json
from datetime import datetime

def save_story(text, lang_code):
    story_obj = {
        "text": text,
        "lang": lang_code,
        "timestamp": datetime.now().isoformat()
    }
    with open("data/stories.json", "a") as f:
        json.dump(story_obj, f)
        f.write("\n")